module.exports = {
    "exchange": {
        "SEHK": "HK",
        "HKFE": "HK",
        "SHSE": "SH",
        "SZSE": "SZ",
        "US": "US",
        "FUND": "F",
        "BOND": "B"
    }
}